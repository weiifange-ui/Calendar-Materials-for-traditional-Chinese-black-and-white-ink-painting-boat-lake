# 水墨萬年曆（PHP 學習版）

這個版本是用來**學 PHP** 的：月曆由 PHP 產生，行程存在 MySQL 資料庫，需要用 XAMPP 執行。
平常使用請用「GitHub 完整版」，那個版本功能比較多，也不需要伺服器。

## 功能

- 萬年曆：年月日、星期、上下月、上下年、回到今天、今年第幾天、剩餘天數
- 農曆、節氣、國定假日、農曆節日、其他節日（用 PHP 計算）
- 帳號：註冊、登入、登出（Session）
- 行程：新增、修改、刪除，分類、重要標記（存在 MySQL）

## 在 XAMPP 執行

1. 安裝並打開 XAMPP，啟動 **Apache** 和 **MySQL**。
2. 把整個 `inkcalendar-php` 資料夾放進 XAMPP 的 `htdocs` 資料夾。
3. 打開 `http://localhost/phpmyadmin`，點上方「匯入」，選擇 `schema.sql`，按「執行」。
4. 把 `includes/config.sample.php` 複製一份，改名成 `includes/config.php`（XAMPP 預設不用改內容）。
5. 打開 `http://localhost/inkcalendar-php/`，註冊一個帳號就能開始使用。

## 檔案說明

```
inkcalendar-php/
├── index.php            首頁：產生月曆、顯示行程、新增／修改表單
├── login.php            登入、註冊
├── logout.php           登出
├── event_save.php       儲存行程（新增、修改）
├── event_delete.php     刪除行程
├── includes/
│   ├── config.sample.php  設定範例（複製成 config.php）
│   ├── db.php             共用：連線資料庫、Session、安全顯示文字
│   ├── lunar.php          農曆換算
│   └── holidays.php       國定假日與節日
├── schema.sql           建立資料庫的 SQL
├── style.css            樣式
└── images/              背景圖片
```

## 建議閱讀順序

每個檔案都有寫給初學者的中文註解。

1. `includes/config.sample.php`：最短的檔案，認識變數
2. `includes/holidays.php`：陣列、if 判斷、函式
3. `includes/lunar.php`：迴圈（for、while）、數學計算
4. `index.php`：最重要的一頁。上半部準備資料，下半部用 PHP 產生 HTML
5. `includes/db.php`：資料庫連線、Session、安全的寫法
6. `login.php`：表單、登入、密碼加密
7. `event_save.php`、`event_delete.php`：新增、修改、刪除資料

## 和 GitHub 完整版（JavaScript）對照

| 做什麼 | GitHub 完整版（JavaScript） | PHP 學習版 |
|---|---|---|
| 畫出月曆 | `js/app.js` 的 `render()`，在瀏覽器裡畫 | `index.php` 的 `for` 迴圈，在伺服器上產生 |
| 切換月份 | 按鈕，畫面不重新載入 | 連結，網址變成 `?y=2026&m=12`，整頁重新載入 |
| 點選日期 | 按鈕，馬上顯示 | 連結，網址多了 `&d=2026-11-10` |
| 新增行程 | 對話框，JavaScript 處理 | 表單送到 `event_save.php` |
| 存行程 | 瀏覽器（localStorage） | MySQL 資料庫 |
| 農曆換算 | `js/lunar.js` | `includes/lunar.php`（同一套演算法） |
| 登入 | 沒有 | `$_SESSION` |

## 安全小知識（程式裡都有用到）

- **`h()`**：顯示使用者輸入的文字前，先轉換特殊符號，避免被當成程式執行。
- **`prepare` 和 `?`**：查資料庫時不直接把使用者輸入接進 SQL，避免 SQL injection 攻擊。
- **`password_hash`**：密碼加密後才存，資料庫裡看不到原本的密碼。
- **CSRF 令牌**：每個表單都藏一組暗號，防止別的網站偷偷幫你送出表單。
- **`user_id = ?`**：修改、刪除時都檢查是不是自己的行程。
