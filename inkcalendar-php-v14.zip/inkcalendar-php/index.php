<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜首頁（index.php）

   【這一頁做了什麼？】
   1. 從網址讀出要看哪一年、哪一月、哪一天（例如 index.php?y=2026&m=11&d=2026-11-10）
   2. 從資料庫讀出這個月的行程
   3. 用 PHP 的迴圈「產生」月曆表格的 HTML
   4. 顯示點選那一天的詳細資料、行程，以及新增／修改行程的表單

   【和 JavaScript 版最大的不同】
   JavaScript 版：月曆在「瀏覽器」裡畫，按下個月時畫面不會重新載入。
   PHP 版：月曆在「伺服器」上產生好，再整頁送給瀏覽器。
           所以按「下個月」其實是一個「連結」，會帶著新的網址重新載入整頁。

   【這個檔案的結構】
   上半部（?> 之前）：純 PHP，負責準備資料
   下半部（?> 之後）：HTML，中間穿插 <?= ?> 把資料放進去
   ========================================================================= */


// ===== 0. 載入共用程式 =====
// require ：把另一個 PHP 檔載入進來，就能使用裡面的函式和變數
require "includes/db.php";          // 資料庫、Session、h()、redirect()……
require "includes/lunar.php";       // 農曆換算
require "includes/holidays.php";    // 國定假日與節日

$user = currentUser();              // 目前登入的人（沒登入是 null）
$WEEK = ["日", "一", "二", "三", "四", "五", "六"];


// ===== 1. 決定要看哪一年、哪一月 =====
// $_GET["y"] ：網址上的 ?y=2026
// ?? date("Y") ：網址沒有 y 的話，就用今年（date("Y") 是今年，date("n") 是這個月）
$year  = (int)($_GET["y"] ?? date("Y"));
$month = (int)($_GET["m"] ?? date("n"));

// 月份超出範圍時自動調整：例如 2026 年 13 月 → 2027 年 1 月
// mktime(時, 分, 秒, 月, 日, 年) ：做出一個時間，PHP 會自動幫你進位
$first = mktime(0, 0, 0, $month, 1, $year);
$year  = (int)date("Y", $first);
$month = (int)date("n", $first);

// 前後月份、前後年份的連結要用的數字
$prev = getdate(mktime(0, 0, 0, $month - 1, 1, $year));   // getdate ：拆成 ["year" => ..., "mon" => ...]
$next = getdate(mktime(0, 0, 0, $month + 1, 1, $year));


// ===== 2. 決定點選的是哪一天 =====
$today = date("Y-m-d");
$picked = $_GET["d"] ?? $today;
// 檢查格式是不是 2026-11-10；不是的話就用今天
// preg_match 的第三個參數 $p 會拿到拆開的年、月、日
// checkdate(月, 日, 年) ：檢查這個日期存不存在（例如 2 月 30 日就不存在）
if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $picked, $p) || !checkdate((int)$p[2], (int)$p[3], (int)$p[1])) {
    $picked = $today;
    preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $picked, $p);
}
$pickedY = (int)$p[1];
$pickedM = (int)$p[2];
$pickedD = (int)$p[3];


// ===== 3. 從資料庫讀出這個月的行程 =====
// $eventsByDate 會長這樣：["2026-11-10" => [行程1, 行程2], "2026-11-12" => [行程3]]
$eventsByDate = [];
if ($user) {
    // 月曆會顯示到上個月底和下個月初，所以範圍抓寬一點（前後各 7 天）
    $from = date("Y-m-d", mktime(0, 0, 0, $month, -6, $year));
    $to   = date("Y-m-d", mktime(0, 0, 0, $month + 1, 7, $year));
    // 也要把「點選的那一天」包含進來（例如點了其他月份的日子）
    $from = min($from, $picked);
    $to   = max($to, $picked);

    // SQL：從 events 表格，找出「這個人」、「日期在範圍內」的行程，
    //      ORDER BY 排序：重要的排前面（DESC 是由大到小），再依時間排
    $stmt = $pdo->prepare(
        "SELECT * FROM events
         WHERE user_id = ? AND event_date BETWEEN ? AND ?
         ORDER BY important DESC, event_time IS NULL, event_time"
    );
    $stmt->execute([$user["id"], $from, $to]);

    // fetchAll ：拿出所有查到的資料；foreach 一筆一筆放進 $eventsByDate
    foreach ($stmt->fetchAll() as $row) {
        $eventsByDate[$row["event_date"]][] = $row;
    }
}


// ===== 4. 如果網址有 ?edit=編號，代表要修改某個行程 =====
$editing = null;
if ($user && isset($_GET["edit"])) {
    // 只能找「自己的」行程（user_id = 自己），別人的行程就算知道編號也拿不到
    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = ? AND user_id = ?");
    $stmt->execute([(int)$_GET["edit"], $user["id"]]);
    $editing = $stmt->fetch() ?: null;      // ?: ：前面是 false 的話就用 null
}


// ===== 5. 今年第幾天、還剩幾天 =====
// date("z") ：今年第幾天（從 0 開始，所以要 +1）；date("L") ：是不是閏年（1 是，0 不是）
$dayOfYear = (int)date("z") + 1;
$daysInYear = date("L") === "1" ? 366 : 365;


// ===== 6. 點選那一天的資料 =====
$pickedInfo = dayFestivals($pickedY, $pickedM, $pickedD);
$pickedLunar = ($pickedY >= 1900 && $pickedY <= 2100) ? lunarText(toLunar($pickedY, $pickedM, $pickedD)) : "";
$pickedTerm = solarTerm($pickedY, $pickedM, $pickedD);
$pickedWeek = $WEEK[(int)date("w", mktime(0, 0, 0, $pickedM, $pickedD, $pickedY))];
$pickedEvents = $eventsByDate[$picked] ?? [];

// 產生網址的小函式：http_build_query 會把陣列變成 y=2026&m=11 這種格式
function link_to($y, $m, $d = null) {
    $params = ["y" => $y, "m" => $m];
    if ($d) {
        $params["d"] = $d;
    }
    return "index.php?" . http_build_query($params);
}

$message = flash();   // 上一頁留下的提示訊息（例如「已新增行程」）

// 下一行的「問號、大於」記號代表：PHP 到這裡暫停，接下來開始是 HTML
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>水墨萬年曆（PHP 學習版）</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<!-- 右上角：登入狀態 -->
<header class="top">
  <?php if ($user): ?>
    <?php /* 下面的「< ?= 值 ? >」寫法（實際上中間沒有空白），是「< ?php echo 值; ? >」的簡寫：把 PHP 的值印進 HTML */ ?>
    <span>你好，<?= h($user["name"]) ?></span>
    <!-- 登出用表單送出（POST），並附上防偽造的暗號 csrf -->
    <form method="post" action="logout.php" class="inline">
      <input type="hidden" name="csrf" value="<?= h(csrfToken()) ?>">
      <button>登出</button>
    </form>
  <?php else: ?>
    <a href="login.php">登入／註冊</a>
  <?php endif; ?>
  <!-- if (...): ... else: ... endif; 是 PHP 在 HTML 裡常用的寫法，和 if { } else { } 意思一樣 -->
</header>

<main class="calendar">
  <h1><?= $year ?> 年 <?= $month ?> 月</h1>

  <!-- 切換月份：全部都是「連結」，點了就會帶著新的網址重新載入整頁 -->
  <nav class="nav">
    <a href="<?= link_to($year - 1, $month) ?>">« 上一年</a>
    <a href="<?= link_to($prev["year"], $prev["mon"]) ?>">‹ 上個月</a>
    <a href="index.php">今天</a>
    <a href="<?= link_to($next["year"], $next["mon"]) ?>">下個月 ›</a>
    <a href="<?= link_to($year + 1, $month) ?>">下一年 »</a>
  </nav>
  <p class="info">今天是 <?= date("Y") ?> 年第 <?= $dayOfYear ?> 天，今年還剩 <?= $daysInYear - $dayOfYear ?> 天</p>

  <?php if ($message): ?>
    <p class="flash"><?= h($message) ?></p>
  <?php endif; ?>

  <table>
    <thead>
      <tr>
        <!-- foreach：把 $WEEK 裡的「日、一、二……」一個一個印成 <th> -->
        <?php foreach ($WEEK as $w): ?><th><?= $w ?></th><?php endforeach; ?>
      </tr>
    </thead>
    <tbody>
    <?php
      // ===== 用迴圈產生月曆的每一格 =====
      $startWeekday = (int)date("w", $first);        // 這個月 1 號是星期幾（0 是星期日）
      $daysInMonth = (int)date("t", $first);         // 這個月有幾天
      $weeks = (int)ceil(($startWeekday + $daysInMonth) / 7);   // 需要幾列；ceil ：無條件進位

      // 總共 $weeks × 7 格，$i 從 0 開始數
      for ($i = 0; $i < $weeks * 7; $i++) {
          // 第 $i 格是哪一天：從 1 號往前推 $startWeekday 天開始
          $time = mktime(0, 0, 0, $month, 1 - $startWeekday + $i, $year);
          $key = date("Y-m-d", $time);
          $d = (int)date("j", $time);                // 幾號（不補 0）
          $weekday = (int)date("w", $time);
          $info = dayFestivals((int)date("Y", $time), (int)date("n", $time), $d);
          $events = $eventsByDate[$key] ?? [];

          // 決定這一格要加哪些 class（CSS 會依照 class 改變外觀）
          $classes = [];
          if ((int)date("n", $time) !== $month) $classes[] = "other";       // 不是這個月的日子
          if ($weekday === 0 || $weekday === 6) $classes[] = "weekend";     // 週末
          if ($info["off"]) $classes[] = "off";                             // 國定假日
          if ($key === $today) $classes[] = "today";                        // 今天
          if ($key === $picked) $classes[] = "picked";                      // 點選的那天

          // % 7 === 0 ：每 7 格換一列
          if ($i % 7 === 0) echo "<tr>";

          // implode(" ", 陣列) ：用空白把陣列接成一段文字，例如 "weekend off"
          echo '<td><a class="' . implode(" ", $classes) . '" href="' . h(link_to($year, $month, $key)) . '">';
          echo '<span class="num">' . $d . '</span>';
          if ($info["off"]) echo '<span class="tag">休</span>';
          // 只顯示第一個節日名稱
          echo '<span class="label">' . h($info["names"][0] ?? "") . '</span>';
          // 只顯示第一個行程的主旨；還有更多就顯示 +幾
          if ($events) {
              echo '<span class="ev">' . ($events[0]["important"] ? "★" : "") . h($events[0]["title"]);
              if (count($events) > 1) echo '<em>+' . (count($events) - 1) . '</em>';
              echo '</span>';
          }
          echo '</a></td>';

          if ($i % 7 === 6) echo "</tr>";
      }
    ?>
    </tbody>
  </table>

  <!-- ===== 點選那一天的詳細資料 ===== -->
  <section class="detail">
    <div class="d-date"><?= $pickedY ?> 年 <?= $pickedM ?> 月 <?= $pickedD ?> 日　星期<?= $pickedWeek ?></div>
    <div class="d-lunar"><?= $pickedLunar ? "農曆 " . $pickedLunar : "農曆只能換算 1900～2100 年" ?><?= $pickedTerm ? "　" . $pickedTerm : "" ?></div>

    <div class="d-fest">
      <?php foreach ($pickedInfo["names"] as $name): ?>
        <span class="chip"><?= h($name) ?></span>
      <?php endforeach; ?>
      <?php if ($pickedInfo["off"] && !$pickedInfo["official"]): ?>
        <span class="note">此年份沒有官方資料，依固定日期推算，不含補假</span>
      <?php endif; ?>
    </div>

    <h2>行程與紀念日</h2>
    <?php if (!$user): ?>
      <p class="muted"><a href="login.php">登入</a>後就可以新增行程。</p>
    <?php else: ?>
      <ul class="ev-list">
        <?php if (!$pickedEvents): ?>
          <li class="muted">這天還沒有安排</li>
        <?php endif; ?>
        <?php foreach ($pickedEvents as $ev): ?>
          <li>
            <div class="ev-main">
              <strong><?= $ev["important"] ? "★ " : "" ?><?= h($ev["title"]) ?></strong>
              <span class="muted">
                <!-- substr(時間, 0, 5)：資料庫的時間是 14:00:00，只取前 5 個字變成 14:00 -->
                <?= $ev["event_time"] ? h(substr($ev["event_time"], 0, 5)) . "　" : "" ?><?= h(CATEGORIES[$ev["category"]] ?? "其他") ?>
              </span>
              <?php if ($ev["note"]): ?>
                <!-- nl2br：把換行變成 <br>，詳細內容的換行才會顯示出來 -->
                <p class="note-text"><?= nl2br(h($ev["note"])) ?></p>
              <?php endif; ?>
            </div>
            <div class="ev-actions">
              <!-- 修改：連到同一頁，網址多帶 edit=編號，下面的表單就會變成修改模式 -->
              <a href="<?= h(link_to($year, $month, $picked)) ?>&edit=<?= (int)$ev["id"] ?>#form">修改</a>
              <!-- 刪除：用表單送出（POST），onsubmit 會先跳出確認視窗 -->
              <form method="post" action="event_delete.php" class="inline" onsubmit="return confirm('確定要刪除嗎？');">
                <input type="hidden" name="csrf" value="<?= h(csrfToken()) ?>">
                <input type="hidden" name="id" value="<?= (int)$ev["id"] ?>">
                <button class="danger">刪除</button>
              </form>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>

      <!-- ===== 新增／修改行程的表單 =====
           method="post"：用 POST 送出（資料裝在信封裡）
           action="event_save.php"：送給 event_save.php 處理 -->
      <form method="post" action="event_save.php" class="ev-form" id="form">
        <h3><?= $editing ? "修改行程" : "新增行程" ?></h3>
        <input type="hidden" name="csrf" value="<?= h(csrfToken()) ?>">
        <?php if ($editing): ?>
          <!-- 修改時，偷偷帶著行程編號，event_save.php 才知道要改哪一個 -->
          <input type="hidden" name="id" value="<?= (int)$editing["id"] ?>">
        <?php endif; ?>

        <!-- name="title"：送出後，PHP 用 $_POST["title"] 拿到這個欄位的值
             required：沒填就不能送出 -->
        <label>主旨<input name="title" maxlength="60" required value="<?= h($editing["title"] ?? "") ?>" placeholder="和朋友吃飯"></label>
        <div class="row">
          <label>日期<input type="date" name="date" required value="<?= h($editing["event_date"] ?? $picked) ?>"></label>
          <label>時間<input type="time" name="time" value="<?= h(isset($editing["event_time"]) ? substr($editing["event_time"], 0, 5) : "") ?>"></label>
        </div>
        <div class="row">
          <label>分類
            <select name="category">
              <?php foreach (CATEGORIES as $value => $text): ?>
                <!-- selected：預設選中這一項 -->
                <option value="<?= $value ?>" <?= ($editing["category"] ?? "life") === $value ? "selected" : "" ?>><?= $text ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label class="check"><input type="checkbox" name="important" value="1" <?= !empty($editing["important"]) ? "checked" : "" ?>> 重要</label>
        </div>
        <label>詳細內容<textarea name="note" rows="3" placeholder="地點、要帶的東西、備註"><?= h($editing["note"] ?? "") ?></textarea></label>
        <div class="actions">
          <?php if ($editing): ?>
            <a href="<?= h(link_to($year, $month, $picked)) ?>">取消修改</a>
          <?php endif; ?>
          <button class="primary"><?= $editing ? "儲存修改" : "新增" ?></button>
        </div>
      </form>
    <?php endif; ?>
  </section>
</main>

<footer class="foot">PHP 學習版：月曆由 PHP 產生、行程存在 MySQL。動畫、天氣、占卜等功能請看 GitHub 完整版。</footer>
</body>
</html>
