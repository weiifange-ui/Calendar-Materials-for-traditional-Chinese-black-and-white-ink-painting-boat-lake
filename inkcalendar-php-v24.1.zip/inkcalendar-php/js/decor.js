/* =========================================================================
   水墨萬年曆 PHP 學習版｜裝飾與小功能的共用程式（js/decor.js）

   這個檔案是 JavaScript，和 PHP 無關。它負責：
   1. 準備每日學習、城市天氣需要的共用工具（存檔、提示、安全顯示文字）
   2. 畫出每個月的水墨花框，以及左下角「改變花框」按鈕

   月曆和行程都是 PHP 處理的；這裡只負責「好看」和「小功能」。
   ========================================================================= */

// ===== 共用工具（study.js、weather.js 會用到） =====
const now = new Date();
const WEEK = ["日", "一", "二", "三", "四", "五", "六"];
// 把 < > & 這些符號換掉，避免文字被當成 HTML
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// 小功能的資料（學習卡、城市清單）存在瀏覽器裡
const STORE_KEY = "inkCalendarPhpWidgets";
let store = {};
try { store = JSON.parse(localStorage.getItem(STORE_KEY) || "{}"); } catch (e) { store = {}; }

// 畫面下方短暫出現的提示文字
function flash(text) {
  let t = document.querySelector(".toast");
  if (!t) { t = document.createElement("div"); t.className = "toast"; t.setAttribute("aria-live", "polite"); document.body.appendChild(t); }
  t.textContent = text; t.classList.add("show");
  clearTimeout(flash.timer);
  flash.timer = setTimeout(() => t.classList.remove("show"), 1400);
}
function save() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(store)); flash("已儲存"); }
  catch (e) { flash("無法存檔，瀏覽器可能關閉了儲存功能"); }
}

// ===== 花框 =====
// 現在看的是幾月：PHP 把月份寫在 <body data-month="11"> 上，這裡讀出來（0 代表一月）
const viewMonth = Number(document.body.dataset.month || now.getMonth() + 1) - 1;

// 每個月記住一個「種子」：同一個種子畫出來的花一模一樣；按「改變花框」就換一個
let seeds = {};
try { seeds = JSON.parse(localStorage.getItem("garlandSeeds") || "{}"); } catch (e) { seeds = {}; }
const seedOf = m => seeds[m] ?? (m + 1) * 1000;

function paintGarlands(month, animate) {
  const boxes = [document.getElementById("gTop"), document.getElementById("gBottom")];
  if (!boxes[0]) return;                                   // 這一頁沒有月曆（例如登入頁）就不畫
  const draw = () => {
    boxes.forEach((box, i) => {
      box.innerHTML = "";
      const w = Math.max(200, Math.round(box.clientWidth));
      const h = Math.round(box.clientHeight);
      const k = .7 * Math.min(1, Math.max(.6, w / 720));
      setSeed(seedOf(month) + i * 7919);                   // 上下兩條用不同的種子
      const svg = el("svg", { viewBox: `0 0 ${w} ${h}` }, box);
      const g = el("g", i === 1 ? { transform: `translate(${w} 0) scale(-1 1)` } : {}, svg);
      drawGarland(g, month, w, h, k);
    });
  };
  if (!animate) return draw();
  boxes.forEach(b => b.classList.add("fade"));
  setTimeout(() => { draw(); boxes.forEach(b => b.classList.remove("fade")); }, 250);
}

const redrawBtn = document.getElementById("redraw");
if (redrawBtn) {
  redrawBtn.addEventListener("click", () => {
    seeds[viewMonth] = Math.floor(Math.random() * 1e9);
    try { localStorage.setItem("garlandSeeds", JSON.stringify(seeds)); } catch (e) {}
    paintGarlands(viewMonth, true);
  });
}
let resizeTimer;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => paintGarlands(viewMonth, false), 200);
});
paintGarlands(viewMonth, false);
