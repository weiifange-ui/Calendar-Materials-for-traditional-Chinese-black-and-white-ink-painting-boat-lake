<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜儲存行程（event_save.php）

   【這一頁做了什麼？】
   index.php 的表單按下「新增」或「儲存修改」後，資料會送到這裡。
   這一頁「沒有畫面」，只負責：檢查資料 → 存進資料庫 → 跳回 index.php

   【表單送來的資料在哪裡？】
   在 $_POST 這個陣列裡。表單欄位的 name 是什麼，就用什麼取：
       <input name="title">  →  $_POST["title"]
   ========================================================================= */

require "includes/db.php";

// 1. 一定要登入；沒登入就帶去登入頁
$user = currentUser();
if (!$user) {
    redirect("login.php");
}

// 2. 一定要用 POST 送來，而且暗號要對
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirect("index.php");
}
checkCsrf();

// 3. 拿出表單資料
// trim ：去掉前後空白；?? "" ：沒有這個欄位就當作空字串
$id        = (int)($_POST["id"] ?? 0);             // 有 id 代表「修改」，0 代表「新增」
$title     = trim($_POST["title"] ?? "");
$date      = $_POST["date"] ?? "";
$time      = $_POST["time"] ?? "";
$category  = $_POST["category"] ?? "life";
$important = isset($_POST["important"]) ? 1 : 0;   // 勾選框：有勾才會送出這個欄位
$note      = trim($_POST["note"] ?? "");

// 4. 檢查資料。就算表單有 required，還是要在 PHP 再檢查一次，
//    因為表單可以被修改，伺服器不能完全相信瀏覽器送來的東西
// mb_strlen ：算中文字數（strlen 算的是位元組，一個中文字算 3）
$length = function_exists("mb_strlen") ? mb_strlen($title) : strlen($title);
if ($title === "" || $length > 60) {
    flash("主旨不能是空的，也不能超過 60 個字");
    redirect("index.php");
}
if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $p) || !checkdate((int)$p[2], (int)$p[3], (int)$p[1])) {
    flash("日期格式不正確");
    redirect("index.php");
}
if ($time !== "" && !preg_match('/^\d{2}:\d{2}$/', $time)) {
    flash("時間格式不正確");
    redirect("index.php");
}
// array_key_exists ：檢查分類是不是 CATEGORIES 裡的其中一個
if (!array_key_exists($category, CATEGORIES)) {
    $category = "other";
}
// 空白的時間存成 NULL（資料庫的「沒有值」）
$timeValue = $time === "" ? null : $time;

// 5. 存進資料庫
if ($id > 0) {
    // 修改：UPDATE 表格 SET 欄位 = 新值 WHERE 條件
    // WHERE 一定要加上 user_id = 自己，才不會改到別人的行程
    $stmt = $pdo->prepare(
        "UPDATE events SET title = ?, event_date = ?, event_time = ?, category = ?, important = ?, note = ?
         WHERE id = ? AND user_id = ?"
    );
    $stmt->execute([$title, $date, $timeValue, $category, $important, $note, $id, $user["id"]]);
    flash("已儲存修改");
} else {
    // 新增：INSERT INTO 表格 (欄位們) VALUES (值們)
    // ? 是空格，真正的值放在 execute([...]) 裡，可以防止 SQL injection 攻擊
    $stmt = $pdo->prepare(
        "INSERT INTO events (user_id, title, event_date, event_time, category, important, note)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([$user["id"], $title, $date, $timeValue, $category, $important, $note]);
    flash("已新增行程");
}

// 6. 跳回月曆，並選在這個行程的日期
redirect("index.php?" . http_build_query(["y" => (int)$p[1], "m" => (int)$p[2], "d" => $date]));
