<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜背景山水（includes/scene.php）

   【這是什麼？】
   這個檔案只有 HTML，沒有 PHP 程式。
   index.php 和 login.php 都需要同一個背景，所以把它獨立出來，
   兩頁用 include "includes/scene.php"; 載入，就不用各寫一次。
   這就是 PHP 的 include 最常見的用法：把好幾頁共用的畫面拆成小檔案。
   ========================================================================= */
?>
<!-- ======================================================================
     一、背景山水畫（分成好幾層疊在一起，竹子和小船才能各自動）

     <div>：一個「區塊」，本身沒有任何意義，就像一個空盒子，用來把東西包在一起
     <img>：顯示圖片。src 是圖片位置；alt 是圖片的文字說明，
            這裡寫 alt="" 是因為背景只是裝飾，不需要說明
     ====================================================================== -->
<div class="scene" aria-hidden="true">
  <div class="art">
    <!-- 第一層：底圖（已經把竹子和船擦掉的山水） -->
    <img class="base" src="images/bg-base.webp" alt="">
    <!-- 第二層：竹子（style.css 會讓它左右搖擺） -->
    <img class="bamboo" src="images/bg-bamboo.webp" alt="">

    <!-- 第三層：船底下的水波
         <svg>：用「程式碼」畫圖的標籤，放大也不會模糊
         viewBox="0 0 320 70"：畫布的座標範圍，寬 320、高 70
         <g>：把幾個圖形包成一組，一起設定顏色和線條粗細
         <ellipse>：橢圓。cx、cy 是中心點；rx、ry 是橫向、直向的半徑
         <path>：自由曲線。d 裡面是畫線的指令（M 移到、q 曲線、t 延續曲線） -->
    <svg class="ripples" viewBox="0 0 320 70">
      <g fill="none" stroke="#222" stroke-linecap="round">
        <!-- 三圈擴散的漣漪（CSS 會讓它們一圈接一圈放大、變淡） -->
        <ellipse class="ring r1" cx="150" cy="20" rx="130" ry="9" stroke-width="2"/>
        <ellipse class="ring r2" cx="150" cy="20" rx="130" ry="9" stroke-width="2"/>
        <ellipse class="ring r3" cx="150" cy="20" rx="130" ry="9" stroke-width="2"/>
        <!-- 三道左右飄動的水紋 -->
        <path class="wave w1" d="M20 30 q12 -4 24 0 t24 0 t24 0" stroke-width="1.6"/>
        <path class="wave w2" d="M205 34 q12 -4 24 0 t24 0 t24 0" stroke-width="1.6"/>
        <path class="wave w3" d="M95 48 q12 -3 24 0 t24 0 t24 0" stroke-width="1.4"/>
      </g>
    </svg>

    <!-- 第四層：船的倒影（和船是同一張圖，CSS 只顯示下半部，並讓它像在水裡晃） -->
    <img class="reflect" src="images/bg-boat.webp" alt="">
    <!-- 第五層：船身（CSS 只顯示上半部，並讓它前後搖晃） -->
    <img class="boat" src="images/bg-boat.webp" alt="">
  </div>
</div>

<!-- ======================================================================
     二、水墨濾鏡（看不見的 SVG，只用來存放「濾鏡」）

     width="0" height="0"：這個 SVG 本身不佔空間、看不見
     <defs>：「定義區」，放在這裡的東西不會畫出來，而是讓別的地方拿去用
     <filter id="名稱">：一個濾鏡。其他圖形寫 filter="url(#名稱)" 就能套用

     濾鏡的原理：
     feTurbulence      ：產生一片隨機的「雜訊」（像宣紙的纖維）
     feDisplacementMap ：讓圖形照著雜訊扭曲，邊緣就會像墨水暈開
     feGaussianBlur    ：模糊
     ====================================================================== -->
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <defs>
    <!-- brush：毛筆的乾筆質感（八卦、銅錢、天氣圖示、入口圓圈） -->
    <filter id="brush" color-interpolation-filters="sRGB" x="-10%" y="-30%" width="120%" height="160%">
      <feTurbulence type="fractalNoise" baseFrequency="0.09" numOctaves="3" seed="4" result="n"/>
      <feDisplacementMap in="SourceGraphic" in2="n" scale="3.5"/>
    </filter>
    <!-- dwash：大範圍淡墨暈染（占卜畫面的背景墨團） -->
    <filter id="dwash" color-interpolation-filters="sRGB" x="-40%" y="-40%" width="180%" height="180%">
      <feTurbulence type="fractalNoise" baseFrequency="0.018" numOctaves="4" seed="11" result="n"/>
      <feDisplacementMap in="SourceGraphic" in2="n" scale="40" result="d"/>
      <feGaussianBlur in="d" stdDeviation="7"/>
    </filter>
    <!-- waterwave：讓倒影像在水中晃動
         <animate>：讓濾鏡的數值隨時間改變，dur="7s" 是 7 秒一輪，repeatCount="indefinite" 是一直重複 -->
    <filter id="waterwave" color-interpolation-filters="sRGB" x="-5%" y="-5%" width="110%" height="110%">
      <feTurbulence type="turbulence" baseFrequency="0.01 0.12" numOctaves="1" seed="3" result="t">
        <animate attributeName="baseFrequency" dur="7s" values="0.01 0.10;0.01 0.16;0.01 0.10" repeatCount="indefinite"/>
      </feTurbulence>
      <feDisplacementMap in="SourceGraphic" in2="t" scale="7"/>
    </filter>
    <!-- ink：讓花瓣、枝條的邊緣微微抖動，像墨水滲進宣紙 -->
    <filter id="ink" color-interpolation-filters="sRGB" x="-20%" y="-20%" width="140%" height="140%">
      <feTurbulence type="fractalNoise" baseFrequency="0.06" numOctaves="3" seed="3" result="n"/>
      <feDisplacementMap in="SourceGraphic" in2="n" scale="4"/>
    </filter>
    <!-- wash：抖動更大、再加一點模糊，像淡墨暈染（葉子、荷葉） -->
    <filter id="wash" color-interpolation-filters="sRGB" x="-30%" y="-30%" width="160%" height="160%">
      <feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="3" seed="8" result="n"/>
      <feDisplacementMap in="SourceGraphic" in2="n" scale="9" result="d"/>
      <feGaussianBlur in="d" stdDeviation="1.4"/>
    </filter>
  </defs>
</svg>

