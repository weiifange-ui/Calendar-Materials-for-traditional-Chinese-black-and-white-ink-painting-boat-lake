<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜右上角的小功能（includes/widgets.php）

   八卦占卜、每日學習、城市天氣三個抽屜，和 GitHub 完整版一模一樣，
   是用 JavaScript 寫的（js 資料夾），和 PHP 無關，所以學習時可以先跳過。
   每日學習和城市天氣的資料存在瀏覽器裡，不會存進資料庫。
   ========================================================================= */
?>
<!-- ======================================================================
     四、八卦占卜（右上角的小八卦 → 從右邊滑出的抽屜）

     <aside>：「側邊內容」，和主要內容相關、但不是主角的東西，很適合抽屜
     inert：抽屜關著的時候，讓鍵盤和螢幕閱讀器跳過它（打開時 JavaScript 會拿掉這個屬性）
     aria-controls="drawer"：告訴螢幕閱讀器「這個按鈕控制 id="drawer" 那個抽屜」
     aria-expanded="false"：目前是關著的（打開時 JavaScript 會改成 true）
     ====================================================================== -->
<button class="launcher" id="launcher" aria-label="打開八卦占卜" aria-controls="drawer" aria-expanded="false">
  <!-- 小八卦的圖案是 divination.js 複製大八卦畫好的內容 -->
  <svg viewBox="-190 -190 380 380" aria-hidden="true"><g id="launcherBagua"></g></svg>
  <!-- <span>：一小段文字，不換行。游標移上去時才顯示「搖卦」 -->
  <span class="tip">搖卦</span>
</button>
<!-- scrim：抽屜打開時，後面那一層淡淡的遮罩，點它可以關閉抽屜 -->
<div class="scrim" id="scrim"></div>
<aside class="drawer" id="drawer" role="dialog" aria-modal="true" aria-label="八卦占卜" inert>
  <div class="drawer-head">
    <!-- <h2>：第二大的標題；<small>：小字 -->
    <h2>易占</h2><small>三錢搖卦</small>
    <span class="seal" aria-hidden="true">問心</span>
    <button class="close" id="closeDrawer" aria-label="關閉占卜">×</button>
  </div>
  <div class="drawer-body" id="drawerBody">
  <!-- 第一階段：點擊八卦 -->
  <section id="stage1">
    <button id="baguaBtn" aria-label="點擊八卦，開始搖卦">
      <svg viewBox="-190 -190 380 380" aria-hidden="true">
        <!-- <circle>：圓形。r 是半徑；currentColor 代表「用目前的文字顏色」，深色模式會自動變色 -->
        <circle r="150" fill="currentColor" fill-opacity=".08" filter="url(#dwash)"/>
        <!-- 八卦和太極由 divination.js 畫進這個 <g> 裡 -->
        <g id="baguaSpin"></g>
      </svg>
    </button>
    <p class="hint" id="hint">靜心默念所問之事　輕點八卦</p>
  </section>

  <!-- 第二階段：搖卦（三枚銅錢＋六爻清單） -->
  <section id="castArea" aria-live="polite">
    <div id="coinBox">
      <svg viewBox="20 60 320 130" role="img" aria-label="三枚銅錢">
        <ellipse cx="180" cy="150" rx="150" ry="34" fill="currentColor" fill-opacity=".07" filter="url(#dwash)"/>
        <g id="coins"></g>
      </svg>
      <p id="castStatus"></p>
    </div>
    <!-- <ol>：有順序的清單（ordered list）。六爻由下往上一行一行出現 -->
    <ol id="yaoList"></ol>
  </section>

  <!-- 第三階段：結果（本卦、變卦） -->
  <section id="result">
    <svg class="divider" viewBox="0 0 700 18" preserveAspectRatio="none" aria-hidden="true">
      <path d="M10 10 C150 6 300 12 450 8 S640 10 690 9" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round" filter="url(#brush)" opacity=".7"/>
    </svg>
    <div class="hexCards" id="hexCards"></div>
    <button class="again" id="againBtn">再占一次</button>
  </section>
  </div>
</aside>

<!-- ======================================================================
     五、每日學習（「學」字入口 → 抽屜）
     ====================================================================== -->
<button class="launcher study" id="studyLauncher" aria-label="打開每日學習" aria-controls="studyDrawer" aria-expanded="false">
  <svg viewBox="-190 -190 380 380" aria-hidden="true"><g>
    <!-- 毛筆畫的圓圈（故意留一個缺口，像書法的「圓相」） -->
    <path d="M-10 -160 C90 -164 162 -92 160 4 C158 100 82 162 -4 160 C-100 156 -162 84 -158 -10 C-154 -88 -98 -146 -32 -158"
      fill="none" stroke="currentColor" stroke-width="14" stroke-linecap="round" filter="url(#brush)"/>
    <!-- <text>：SVG 裡的文字。text-anchor="middle" 讓文字以 x 為中心置中 -->
    <text x="0" y="52" text-anchor="middle" fill="currentColor">學</text>
  </g></svg>
  <span class="tip">每日學習</span>
</button>
<div class="scrim" id="studyScrim"></div>
<aside class="drawer" id="studyDrawer" role="dialog" aria-modal="true" aria-label="每日學習" inert>
  <div class="drawer-head">
    <h2>每日一學</h2>
    <button class="close" id="closeStudy" aria-label="關閉每日學習">×</button>
  </div>
  <!-- 分頁按鈕。data-tab="en"：「data-」開頭的屬性是自己取名、用來存資料的，
       study.js 會讀它，知道按的是哪一個分頁 -->
  <div class="s-tabs" id="studyTabs" role="tablist">
    <button role="tab" data-tab="en" aria-selected="true">英文</button>
    <button role="tab" data-tab="code" aria-selected="false">程式</button>
  </div>
  <div class="drawer-body" id="studyBody">
    <div class="s-bar"><span id="studyWhen"></span><span id="studyCount"></span></div>
    <!-- 學習卡的內容由 study.js 填入 -->
    <div class="s-card" id="studyCard" aria-live="polite"></div>
    <div class="s-nav">
      <button class="link" id="prevCard">‹ 上一則</button>
      <button class="link" id="todayCard" hidden>回到今天</button>
      <span class="spacer"></span>
      <button class="link" id="nextCard">下一則 ›</button>
    </div>
    <p class="s-progress" id="studyProgress"></p>

    <!-- <details>：可以展開、收起的區塊；<summary> 是一直看得到的那一行，點它就會展開 -->
    <details class="s-add">
      <summary>新增學習卡</summary>
      <!-- <select>：下拉選單；<option>：選單裡的每一個選項，value 是程式讀到的值 -->
      <label>種類
        <select id="cType"><option value="en">英文</option><option value="code">程式</option></select>
      </label>
      <!-- <input>：單行輸入框。maxlength 是最多幾個字；autocomplete="off" 是不要跳出瀏覽器記住的文字 -->
      <label id="lFront">單字<input id="cFront" maxlength="80" autocomplete="off"></label>
      <label id="lPos">詞性（選填）<input id="cPos" maxlength="20" placeholder="名詞" autocomplete="off"></label>
      <label id="lMeaning">中文意思<input id="cMeaning" maxlength="200" autocomplete="off"></label>
      <label id="lExample">例句（選填）<textarea id="cExample" rows="3"></textarea></label>
      <label id="lTrans">例句翻譯（選填）<input id="cTrans" maxlength="200" autocomplete="off"></label>
      <!-- 錯誤訊息，例如「請輸入單字」 -->
      <p class="err" id="cErr" aria-live="polite"></p>
      <div class="btnrow"><button id="addCard">新增這張卡</button></div>

      <!-- <code>：程式碼文字；<br>：換行 -->
      <p class="hint2">一次新增很多張：每行一張，用 <code>|</code> 分隔。<br>
        英文：<code>單字 | 意思 | 例句 | 翻譯</code><br>
        程式：<code>標題 | 說明 | 程式碼</code>（程式碼換行寫成 <code>\n</code>）</p>
      <label>貼上多張（種類依照上面的選擇）<textarea id="bulkText" rows="4" placeholder="harvest | 收穫 | We harvest rice in autumn. | 我們在秋天收割稻米。"></textarea></label>
      <p class="err" id="bulkErr" aria-live="polite"></p>
      <div class="btnrow"><button id="bulkAdd">全部新增</button></div>
    </details>
  </div>
</aside>

<!-- ======================================================================
     六、城市天氣（「氣」字入口 → 抽屜）
     ====================================================================== -->
<button class="launcher weather" id="weatherLauncher" aria-label="打開城市天氣" aria-controls="weatherDrawer" aria-expanded="false">
  <svg viewBox="-190 -190 380 380" aria-hidden="true"><g>
    <path d="M6 -160 C100 -158 164 -84 160 10 C156 104 78 164 -10 160 C-104 154 -164 80 -158 -16 C-152 -94 -92 -150 -24 -159"
      fill="none" stroke="currentColor" stroke-width="14" stroke-linecap="round" filter="url(#brush)"/>
    <text x="0" y="52" text-anchor="middle" fill="currentColor">氣</text>
  </g></svg>
  <span class="tip">城市天氣</span>
</button>
<div class="scrim" id="weatherScrim"></div>
<aside class="drawer" id="weatherDrawer" role="dialog" aria-modal="true" aria-label="城市天氣" inert>
  <div class="drawer-head">
    <h2>城市天氣</h2>
    <button class="close" id="closeWeather" aria-label="關閉城市天氣">×</button>
  </div>
  <div class="s-tabs" id="wTabs" role="tablist">
    <button role="tab" data-view="list" aria-selected="true">城市</button>
    <button role="tab" data-view="compare" aria-selected="false">清單</button>
  </div>
  <div class="drawer-body" id="weatherBody">
    <!-- 加入城市：從下拉選單選（選項由 weather.js 產生） -->
    <div class="w-add">
      <select id="wSelect" aria-label="選擇城市"></select>
      <!-- 選了台灣的縣市之後，才會出現這個「鄉鎮市區」選單 -->
      <select id="wTown" aria-label="選擇鄉鎮市區" hidden></select>
      <button class="w-btn" id="wAdd">加入</button>
    </div>
    <!-- 或是用英文名稱搜尋 -->
    <div class="w-add">
      <input id="wSearch" placeholder="其他城市：輸入英文，例如 Kyoto" aria-label="用英文名稱搜尋其他城市" autocomplete="off">
      <button class="w-btn" id="wSearchBtn">搜尋</button>
    </div>
    <p class="err" id="wErr" aria-live="polite"></p>
    <ul class="w-results" id="wResults"></ul>

    <!-- 每個城市的天氣卡片由 weather.js 產生 -->
    <div id="wList" aria-live="polite"></div>

    <!-- <footer>：區塊的「頁尾」，放資料來源、更新時間 -->
    <footer class="w-foot">
      <div><span id="wStatus"></span><button class="link" id="wRefresh">重新整理</button></div>
      <p>天氣資料：Open-Meteo<br><span id="wAlertState"></span></p>
    </footer>
  </div>
</aside>

