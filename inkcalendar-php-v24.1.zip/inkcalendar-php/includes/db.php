<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜共用程式（includes/db.php）

   【這個檔案是做什麼的？】
   每一頁都需要：連線資料庫、記住誰登入了、安全地顯示文字。
   寫在這裡，每一頁開頭用 require 載入就好，不用重複寫。
   ========================================================================= */

date_default_timezone_set("Asia/Taipei");   // 時區設為台灣


// ===== 1. 讀取設定（資料庫帳號密碼） =====
// __DIR__ ：這個檔案所在的資料夾（includes）
if (!file_exists(__DIR__ . "/config.php")) {
    // die ：顯示訊息並停止程式
    die("找不到 includes/config.php，請先把 config.sample.php 複製一份，改名成 config.php");
}
require __DIR__ . "/config.php";


// ===== 2. 連線資料庫 =====
// PDO 是 PHP 內建的資料庫工具。new PDO(...) 會建立一條連線，存進 $pdo 變數。
// try { ... } catch { ... } ：「試試看」，出錯時不會整個當掉，而是跳到 catch 處理。
try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,          // 出錯時讓 catch 接住
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC      // 查詢結果用欄位名稱取值，例如 $row["title"]
        ]
    );
} catch (PDOException $e) {
    die("無法連線到資料庫：請確認 XAMPP 的 MySQL 有啟動，並且已經匯入 schema.sql");
}


// ===== 3. 記住誰登入了：Session =====
// Session 像「寄物櫃」：伺服器幫你保管資料（例如你是誰），
// 給瀏覽器一張號碼牌（Cookie），下次帶著號碼牌來，就知道你是誰。
// session_start() 之後，就能用 $_SESSION 這個陣列存取寄物櫃裡的東西。
session_start();


// ===== 4. 安全地顯示文字：h() =====
// 使用者輸入的文字（例如行程主旨）如果包含 <script>，直接顯示會被當成程式執行，很危險。
// htmlspecialchars 會把 < > " 這些符號換成安全的寫法，畫面上看起來一樣，但不會被執行。
// 規則：只要是「使用者輸入的東西」要放進 HTML，都要先經過 h()。
function h($text) {
    return htmlspecialchars((string)$text, ENT_QUOTES, "UTF-8");
}


// ===== 5. 跳到別的頁面：redirect() =====
// header("Location: ...") 會叫瀏覽器「去這個網址」。
// 表單送出、處理完之後跳回原本的頁面，這樣按重新整理才不會重複送出。
function redirect($url) {
    header("Location: " . $url);
    exit;   // 跳轉之後，後面的程式都不要執行
}


// ===== 6. 一次性的提示訊息：flash() =====
// 例如「已新增行程」：存進寄物櫃，下一頁顯示一次之後就刪掉。
function flash($message = null) {
    if ($message !== null) {                 // 有傳訊息進來：存起來
        $_SESSION["flash"] = $message;
        return null;
    }
    $saved = $_SESSION["flash"] ?? null;     // 沒傳：拿出來，並且刪掉
    unset($_SESSION["flash"]);               // unset ：刪除
    return $saved;
}


// ===== 7. 防止別人偽造表單：CSRF 令牌 =====
// 壞人可能做一個假網站，偷偷幫你送出「刪除行程」的表單。
// 防法：每個表單都藏一組只有我們知道的「暗號」（令牌），送出時檢查暗號對不對。
// random_bytes ：產生隨機資料；bin2hex ：轉成看得懂的英文數字
function csrfToken() {
    if (empty($_SESSION["csrf"])) {
        $_SESSION["csrf"] = bin2hex(random_bytes(16));
    }
    return $_SESSION["csrf"];
}
// 檢查表單送來的暗號；不對就停止
// hash_equals ：安全地比較兩段文字是否相同
function checkCsrf() {
    if (!hash_equals(csrfToken(), $_POST["csrf"] ?? "")) {
        die("表單已過期，請回上一頁重新整理後再試一次");
    }
}


// ===== 8. 目前登入的使用者 =====
// 有登入：回傳 ["id" => 編號, "name" => 帳號]；沒登入：回傳 null
function currentUser() {
    if (empty($_SESSION["user_id"])) {
        return null;
    }
    return ["id" => (int)$_SESSION["user_id"], "name" => $_SESSION["username"]];
}

// 行程的分類（存進資料庫的值 => 顯示的文字）
const CATEGORIES = ["work" => "工作", "life" => "生活", "birthday" => "生日", "anniversary" => "紀念日", "other" => "其他"];
