-- =========================================================================
-- 水墨萬年曆 PHP 學習版｜建立資料庫（schema.sql）
--
-- 用法：XAMPP 啟動 MySQL → 打開 http://localhost/phpmyadmin
--       → 上方「匯入」→ 選這個檔案 → 按「執行」。只要做一次。
-- SQL 裡，兩個減號開頭的是註解。
-- =========================================================================

-- 建立資料庫（已經有就不會重複建立）；utf8mb4 讓中文能正確存放
CREATE DATABASE IF NOT EXISTS inkcalendar_php DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inkcalendar_php;

-- ===== 帳號 =====
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,                 -- 編號：自動 +1
  username      VARCHAR(30)  NOT NULL UNIQUE,                   -- 帳號：不能重複
  password_hash VARCHAR(255) NOT NULL,                          -- 加密後的密碼
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP  -- 註冊時間
);

-- ===== 行程（每一列是一個行程）=====
CREATE TABLE IF NOT EXISTS events (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT          NOT NULL,                  -- 這是誰的行程（對應 users 的 id）
  title      VARCHAR(60)  NOT NULL,                  -- 主旨
  event_date DATE         NOT NULL,                  -- 日期，例如 2026-11-10
  event_time TIME         NULL,                      -- 時間（可以不填，NULL 代表沒有值）
  category   VARCHAR(20)  NOT NULL DEFAULT 'life',   -- 分類
  important  TINYINT(1)   NOT NULL DEFAULT 0,        -- 重要：1 是，0 不是
  note       TEXT         NULL,                      -- 詳細內容
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (user_id, event_date),                       -- 索引：讓「找某人某天的行程」變快
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
