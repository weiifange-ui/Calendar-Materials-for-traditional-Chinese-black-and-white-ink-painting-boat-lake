<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜登出（logout.php）
   清空 Session（寄物櫃），就等於登出了
   ========================================================================= */

require "includes/db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    checkCsrf();
    $_SESSION = [];          // 清空寄物櫃
    session_destroy();       // 把寄物櫃拆掉
    session_start();         // 開一個新的空櫃子，才能放下一句提示訊息
    flash("已登出");
}
redirect("index.php");
