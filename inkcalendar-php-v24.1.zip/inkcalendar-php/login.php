<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜登入／註冊（login.php）

   【這一頁有兩種狀態】
   1. 第一次打開（GET）：顯示表單
   2. 按下按鈕送出（POST）：檢查帳號密碼 → 成功就跳回首頁；失敗就再顯示一次表單和錯誤訊息

   網址 login.php                → 登入
   網址 login.php?mode=register  → 註冊
   ========================================================================= */

require "includes/db.php";

// 已經登入了，就不用再登入
if (currentUser()) {
    redirect("index.php");
}

// 目前是登入還是註冊
$mode = ($_GET["mode"] ?? "") === "register" ? "register" : "login";
$error = "";           // 錯誤訊息，一開始是空的
$username = "";        // 讓表單送出失敗時，帳號欄不用重打


// ===== 按下按鈕送出的時候（POST）才會執行這一段 =====
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    checkCsrf();
    $mode = ($_POST["mode"] ?? "") === "register" ? "register" : "login";
    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    // 檢查格式
    if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $username)) {
        $error = "帳號要 3～20 個字，只能用英文字母、數字或底線";
    } elseif (strlen($password) < 6) {
        $error = "密碼至少要 6 個字";
    } elseif ($mode === "register") {
        // ===== 註冊 =====
        // 先看帳號有沒有人用過
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = "這個帳號已經有人使用了";
        } else {
            // password_hash ：把密碼加密後再存，資料庫裡看不到原本的密碼
            $stmt = $pdo->prepare("INSERT INTO users (username, password_hash) VALUES (?, ?)");
            $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
            // 註冊完直接登入：把「你是誰」放進寄物櫃（Session）
            session_regenerate_id(true);    // 換一張新的號碼牌，比較安全
            $_SESSION["user_id"] = (int)$pdo->lastInsertId();
            $_SESSION["username"] = $username;
            flash("註冊成功，歡迎使用！");
            redirect("index.php");
        }
    } else {
        // ===== 登入 =====
        $stmt = $pdo->prepare("SELECT id, password_hash FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $row = $stmt->fetch();
        // password_verify ：檢查輸入的密碼和加密後的密碼對不對得上
        if ($row && password_verify($password, $row["password_hash"])) {
            session_regenerate_id(true);
            $_SESSION["user_id"] = (int)$row["id"];
            $_SESSION["username"] = $username;
            flash("登入成功");
            redirect("index.php");
        }
        $error = "帳號或密碼不正確";
    }
}
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= $mode === "register" ? "註冊" : "登入" ?>｜水墨萬年曆（PHP 學習版）</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="decor.css">
</head>
<body>
<?php include "includes/scene.php"; ?>
<main class="calendar login">
  <h1><?= $mode === "register" ? "註冊" : "登入" ?></h1>

  <!-- 有錯誤訊息才顯示 -->
  <?php if ($error): ?>
    <p class="flash error"><?= h($error) ?></p>
  <?php endif; ?>

  <!-- 表單：沒有寫 action，代表送回「這一頁」（login.php）自己處理 -->
  <form method="post" class="ev-form">
    <input type="hidden" name="csrf" value="<?= h(csrfToken()) ?>">
    <input type="hidden" name="mode" value="<?= $mode ?>">
    <!-- autocomplete：讓瀏覽器知道這是帳號、密碼欄位，可以幫你記住 -->
    <label>帳號<input name="username" required maxlength="20" autocomplete="username" value="<?= h($username) ?>" placeholder="英文字母、數字或底線"></label>
    <!-- type="password"：輸入的字會變成圓點 -->
    <label>密碼<input type="password" name="password" required autocomplete="<?= $mode === "register" ? "new-password" : "current-password" ?>" placeholder="至少 6 個字"></label>
    <div class="actions">
      <?php if ($mode === "register"): ?>
        <a href="login.php">已經有帳號？登入</a>
      <?php else: ?>
        <a href="login.php?mode=register">還沒有帳號？註冊</a>
      <?php endif; ?>
      <button class="primary"><?= $mode === "register" ? "註冊" : "登入" ?></button>
    </div>
  </form>
  <p class="muted"><a href="index.php">← 回到月曆</a></p>
</main>
</body>
</html>
