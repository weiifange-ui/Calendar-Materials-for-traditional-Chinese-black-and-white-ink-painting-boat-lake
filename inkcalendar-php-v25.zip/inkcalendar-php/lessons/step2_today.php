<?php
/* =========================================================================
   第 2 步：今年第幾天、回到今天、點選日期
   （以第 1 步為基礎，新增的地方都標了「★ 新增」）

   這一步學到：
   - date("z")、date("L")：今年第幾天、是不是閏年
   - 在連結後面多帶一個 ?date=2026-11-12，點了就知道選的是哪一天
   - checkdate()：檢查日期是不是真的存在
   ========================================================================= */
// ===== 1. 從網址拿年、月；網址沒有就用這個月 =====
$month = (int)($_GET['month'] ?? date('n'));   // (int) 轉成數字
$year  = (int)($_GET['year'] ?? date('Y'));

// ===== 2. 上一個月、下一個月 =====
if ($month == 1) {               // 1 月的上一個月是去年 12 月
    $prev_month = 12;
    $prev_year = $year - 1;
} else {
    $prev_month = $month - 1;
    $prev_year = $year;
}
if ($month == 12) {              // 12 月的下一個月是明年 1 月
    $next_month = 1;
    $next_year = $year + 1;
} else {
    $next_month = $month + 1;
    $next_year = $year;
}

// ===== 3. 算出月曆需要的數字 =====
$firstDay = "$year-$month-1";                                  // 這個月 1 號，例如 "2026-11-1"
$firstDayWeek = date("w", strtotime($firstDay));               // 1 號是星期幾（0 是星期日）
$theMonthDays = date("t", strtotime($firstDay));               // 這個月有幾天
$theMonthFirstDate = strtotime("-$firstDayWeek day", strtotime($firstDay));   // 月曆第一格的日期（往前推到星期日）
$theMonthTotalDays = $theMonthDays + $firstDayWeek;            // 前面空格 + 這個月的天數
$theCalendarWeeks = ceil($theMonthTotalDays / 7);              // 需要幾列（ceil 無條件進位）
// echo $firstDayWeek;      // 想看數字的時候，把前面的 // 拿掉就會印出來

// ★ 新增：今年第幾天、還剩幾天
$dayOfYear = date("z") + 1;                       // date("z") 從 0 開始算，所以 +1
$daysInYear = date("L") == 1 ? 366 : 365;         // date("L") 是 1 代表閏年
$daysLeft = $daysInYear - $dayOfYear;

// ★ 新增：點選的是哪一天（網址上的 ?date=2026-11-12；沒有就是今天）
$picked = $_GET['date'] ?? date("Y-m-d");
$parts = explode("-", $picked);                   // explode：用「-」切開 → ["2026", "11", "12"]
if (count($parts) != 3 || !checkdate((int)$parts[1], (int)$parts[2], (int)$parts[0])) {
    $picked = date("Y-m-d");                      // 格式不對、或日期不存在（例如 2 月 30 日）就用今天
}
$week_str = ["日", "一", "二", "三", "四", "五", "六"];

$t_month_str = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>第 2 步：今年第幾天、點選日期</title>
<link rel="stylesheet" href="lesson.css">
</head>
<body>
<div class="box">
<p class="step">第 2 步：今年第幾天、回到今天、點選日期</p>
<h2><?= $year ?> 年 <?= $t_month_str[$month - 1] ?></h2>
<div class="nav">
    <a href="step2_today.php?month=<?= $prev_month ?>&year=<?= $prev_year ?>">‹ 上一個月</a>
    <a href="step2_today.php">今天</a>   <!-- ★ 新增：不帶任何資料，就會回到這個月 -->
    <a href="step2_today.php?month=<?= $next_month ?>&year=<?= $next_year ?>">下一個月 ›</a>
</div>
<!-- ★ 新增 -->
<p class="info">今天是 <?= date("Y") ?> 年第 <?= $dayOfYear ?> 天，今年還剩 <?= $daysLeft ?> 天</p>
<table id="calendar">
    <tr>
        <td class="weekend">日</td><td>一</td><td>二</td><td>三</td><td>四</td><td>五</td><td class="weekend">六</td>
    </tr>
<?php
for ($i = 0; $i < $theCalendarWeeks; $i++) {          // 一列一列畫
    echo "<tr>";
    for ($j = 0; $j < 7; $j++) {                      // 每一列 7 格
        $days = $i * 7 + $j;                          // 這是第幾格（從 0 開始）
        $date = strtotime("+$days day", $theMonthFirstDate);   // 這一格是哪一天

        $class = "";
        if (date("w", $date) == 0 || date("w", $date) == 6) {
            $class = $class . " weekend ";            // 週末
        }
        if (date("Y-m-d") == date("Y-m-d", $date)) {
            $class = $class . " today ";              // 今天
        }
        if ($picked == date("Y-m-d", $date)) {
            $class = $class . " picked ";             // ★ 新增：點選的那一天
        }

        echo "<td class='$class'>";
        if (date("n", $date) == $month) {             // 只顯示這個月的日子
            // ★ 新增：日期變成連結，網址帶著這一天
            $link = "step2_today.php?month=$month&year=$year&date=" . date("Y-m-d", $date);
            echo "<a href='$link'>" . date("j", $date) . "</a>";
        }
        echo "</td>";
    }
    echo "</tr>";
}
?>
</table>

<!-- ★ 新增：點選那一天的資料 -->
<div class="detail">
    <?= date("Y 年 n 月 j 日", strtotime($picked)) ?>　星期<?= $week_str[date("w", strtotime($picked))] ?>
</div>
</div>
</body>
</html>
