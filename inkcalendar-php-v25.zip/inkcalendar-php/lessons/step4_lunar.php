<?php
/* =========================================================================
   第 4 步：農曆（以第 3 步為基礎，新增的地方標了「★ 新增」）

   這一步學到：
   - require：載入另一個 PHP 檔，就能使用它寫好的函式
   - 呼叫函式：toLunar(年, 月, 日) 把國曆換成農曆，lunarText() 把結果變成文字

   農曆怎麼算的，寫在 ../includes/lunar.php，現在先「會用」就好，
   就像用 date() 的時候，也不用知道它裡面怎麼寫的。
   ========================================================================= */
// ★ 新增：載入農曆換算的函式（../ 代表「上一層資料夾」）
require "../includes/lunar.php";

// ===== 1. 從網址拿年、月；網址沒有就用這個月 =====
$month = (int)($_GET['month'] ?? date('n'));   // (int) 轉成數字
$year  = (int)($_GET['year'] ?? date('Y'));

// ===== 2. 上一個月、下一個月 =====
if ($month == 1) {               // 1 月的上一個月是去年 12 月
    $prev_month = 12;
    $prev_year = $year - 1;
} else {
    $prev_month = $month - 1;
    $prev_year = $year;
}
if ($month == 12) {              // 12 月的下一個月是明年 1 月
    $next_month = 1;
    $next_year = $year + 1;
} else {
    $next_month = $month + 1;
    $next_year = $year;
}

// ===== 3. 算出月曆需要的數字 =====
$firstDay = "$year-$month-1";                                  // 這個月 1 號，例如 "2026-11-1"
$firstDayWeek = date("w", strtotime($firstDay));               // 1 號是星期幾（0 是星期日）
$theMonthDays = date("t", strtotime($firstDay));               // 這個月有幾天
$theMonthFirstDate = strtotime("-$firstDayWeek day", strtotime($firstDay));   // 月曆第一格的日期（往前推到星期日）
$theMonthTotalDays = $theMonthDays + $firstDayWeek;            // 前面空格 + 這個月的天數
$theCalendarWeeks = ceil($theMonthTotalDays / 7);              // 需要幾列（ceil 無條件進位）
// echo $firstDayWeek;      // 想看數字的時候，把前面的 // 拿掉就會印出來

// 今年第幾天、還剩幾天
$dayOfYear = date("z") + 1;                       // date("z") 從 0 開始算，所以 +1
$daysInYear = date("L") == 1 ? 366 : 365;         // date("L") 是 1 代表閏年
$daysLeft = $daysInYear - $dayOfYear;

// 點選的是哪一天（網址上的 ?date=2026-11-12；沒有就是今天）
$picked = $_GET['date'] ?? date("Y-m-d");
$parts = explode("-", $picked);                   // explode：用「-」切開 → ["2026", "11", "12"]
if (count($parts) != 3 || !checkdate((int)$parts[1], (int)$parts[2], (int)$parts[0])) {
    $picked = date("Y-m-d");                      // 格式不對、或日期不存在（例如 2 月 30 日）就用今天
}
$week_str = ["日", "一", "二", "三", "四", "五", "六"];

// 2026 年的放假日（行政院人事行政總處公告）
$holidays = [
    "2026-01-01" => "開國紀念日",
    "2026-02-15" => "除夕前一日", "2026-02-16" => "除夕", "2026-02-17" => "春節", "2026-02-18" => "春節", "2026-02-19" => "春節", "2026-02-20" => "補假",
    "2026-02-27" => "補假", "2026-02-28" => "和平紀念日",
    "2026-04-03" => "補假", "2026-04-04" => "兒童節", "2026-04-05" => "清明節", "2026-04-06" => "補假",
    "2026-05-01" => "勞動節", "2026-06-19" => "端午節",
    "2026-09-25" => "中秋節", "2026-09-28" => "教師節",
    "2026-10-09" => "補假", "2026-10-10" => "國慶日",
    "2026-10-25" => "光復節", "2026-10-26" => "補假",
    "2026-12-25" => "行憲紀念日",
];
// 每年都一樣的節日，用 "月-日"（和老師的寫法一樣）
$special_days = [
    "02-14" => "情人節",
    "08-08" => "父親節",
    "11-11" => "光棍節",
    "12-24" => "平安夜",
];

$t_month_str = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>第 4 步：農曆</title>
<link rel="stylesheet" href="lesson.css">
</head>
<body>
<div class="box">
<p class="step">第 4 步：農曆</p>
<h2><?= $year ?> 年 <?= $t_month_str[$month - 1] ?></h2>
<div class="nav">
    <a href="step4_lunar.php?month=<?= $prev_month ?>&year=<?= $prev_year ?>">‹ 上一個月</a>
    <a href="step4_lunar.php">今天</a>   <!-- 不帶任何資料，就會回到這個月 -->
    <a href="step4_lunar.php?month=<?= $next_month ?>&year=<?= $next_year ?>">下一個月 ›</a>
</div>
<p class="info">今天是 <?= date("Y") ?> 年第 <?= $dayOfYear ?> 天，今年還剩 <?= $daysLeft ?> 天</p>
<table id="calendar">
    <tr>
        <td class="weekend">日</td><td>一</td><td>二</td><td>三</td><td>四</td><td>五</td><td class="weekend">六</td>
    </tr>
<?php
for ($i = 0; $i < $theCalendarWeeks; $i++) {          // 一列一列畫
    echo "<tr>";
    for ($j = 0; $j < 7; $j++) {                      // 每一列 7 格
        $days = $i * 7 + $j;                          // 這是第幾格（從 0 開始）
        $date = strtotime("+$days day", $theMonthFirstDate);   // 這一格是哪一天

        $class = "";
        if (date("w", $date) == 0 || date("w", $date) == 6) {
            $class = $class . " weekend ";            // 週末
        }
        if (date("Y-m-d") == date("Y-m-d", $date)) {
            $class = $class . " today ";              // 今天
        }
        if ($picked == date("Y-m-d", $date)) {
            $class = $class . " picked ";             // 點選的那一天
        }

        $key = date("Y-m-d", $date);                  // 例如 "2026-10-10"
        $md  = date("m-d", $date);                    // 例如 "10-10"
        if (isset($holidays[$key])) {
            $class = $class . " holiday ";            // 國定假日變成朱砂色
        }

        echo "<td class='$class'>";
        if (date("n", $date) == $month) {             // 只顯示這個月的日子
            // 日期變成連結，網址帶著這一天
            $link = "step4_lunar.php?month=$month&year=$year&date=" . date("Y-m-d", $date);
            echo "<a href='$link'>" . date("j", $date);
            // 假日顯示「休」和名稱；其他節日只顯示名稱
            if (isset($holidays[$key])) {
                echo " <span class='tag'>休</span>";
                echo "<span class='sp_text'>" . $holidays[$key] . "</span>";
            } elseif (isset($special_days[$md])) {
                echo "<span class='sp_text'>" . $special_days[$md] . "</span>";
            }
            echo "</a>";
        }
        echo "</td>";
    }
    echo "</tr>";
}
?>
</table>

<!-- 點選那一天的資料 -->
<div class="detail">
    <?= date("Y 年 n 月 j 日", strtotime($picked)) ?>　星期<?= $week_str[date("w", strtotime($picked))] ?>
    <?php
    // ★ 新增：點選那一天的農曆，例如「丙午年（馬）十月初四」
    $pickedTime = strtotime($picked);
    $lunar = toLunar((int)date("Y", $pickedTime), (int)date("n", $pickedTime), (int)date("j", $pickedTime));
    ?>
    <br><small>農曆 <?= lunarText($lunar) ?></small>
    <?php if (isset($holidays[$picked])): ?>
        <br>放假：<?= $holidays[$picked] ?>
    <?php endif; ?>
</div>
</div>
</body>
</html>
