<?php
/* =========================================================================
   第 1 步：畫出一個月的月曆（和老師的 calendar.php 幾乎一樣）

   這一步學到：
   - $_GET 從網址拿資料（?month=11&year=2026）
   - date()、strtotime() 計算日期
   - for 迴圈畫出表格

   和老師的版本只差兩個小地方（有標 ★ 的那兩行）：
   ★1 用 (int) 把網址上的值轉成數字，比較安全
   ★2 第一天用 "$year-$month-1"，才會跟著年份走
      （老師寫的 date("Y-$month-1") 裡的 Y 永遠是「今年」，
        翻到明年時，表格還是會畫今年的那個月）
   ========================================================================= */

// ===== 1. 從網址拿年、月；網址沒有就用這個月 =====
$month = (int)($_GET['month'] ?? date('n'));   // ★1 (int) 轉成數字
$year  = (int)($_GET['year'] ?? date('Y'));

// ===== 2. 上一個月、下一個月 =====
if ($month == 1) {               // 1 月的上一個月是去年 12 月
    $prev_month = 12;
    $prev_year = $year - 1;
} else {
    $prev_month = $month - 1;
    $prev_year = $year;
}
if ($month == 12) {              // 12 月的下一個月是明年 1 月
    $next_month = 1;
    $next_year = $year + 1;
} else {
    $next_month = $month + 1;
    $next_year = $year;
}

// ===== 3. 算出月曆需要的數字 =====
$firstDay = "$year-$month-1";                                  // ★2 這個月 1 號，例如 "2026-11-1"
$firstDayWeek = date("w", strtotime($firstDay));               // 1 號是星期幾（0 是星期日）
$theMonthDays = date("t", strtotime($firstDay));               // 這個月有幾天
$theMonthFirstDate = strtotime("-$firstDayWeek day", strtotime($firstDay));   // 月曆第一格的日期（往前推到星期日）
$theMonthTotalDays = $theMonthDays + $firstDayWeek;            // 前面空格 + 這個月的天數
$theCalendarWeeks = ceil($theMonthTotalDays / 7);              // 需要幾列（ceil 無條件進位）
// echo $firstDayWeek;      // 想看數字的時候，把前面的 // 拿掉就會印出來

$t_month_str = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>第 1 步：月曆</title>
<link rel="stylesheet" href="lesson.css">
</head>
<body>
<div class="box">
<p class="step">第 1 步：畫出月曆</p>
<h2><?= $year ?> 年 <?= $t_month_str[$month - 1] ?></h2>
<div class="nav">
    <a href="step1_calendar.php?month=<?= $prev_month ?>&year=<?= $prev_year ?>">‹ 上一個月</a>
    <a href="step1_calendar.php?month=<?= $next_month ?>&year=<?= $next_year ?>">下一個月 ›</a>
</div>
<table id="calendar">
    <tr>
        <td class="weekend">日</td><td>一</td><td>二</td><td>三</td><td>四</td><td>五</td><td class="weekend">六</td>
    </tr>
<?php
for ($i = 0; $i < $theCalendarWeeks; $i++) {          // 一列一列畫
    echo "<tr>";
    for ($j = 0; $j < 7; $j++) {                      // 每一列 7 格
        $days = $i * 7 + $j;                          // 這是第幾格（從 0 開始）
        $date = strtotime("+$days day", $theMonthFirstDate);   // 這一格是哪一天

        $class = "";
        if (date("w", $date) == 0 || date("w", $date) == 6) {
            $class = $class . " weekend ";            // 週末
        }
        if (date("Y-m-d") == date("Y-m-d", $date)) {
            $class = $class . " today ";              // 今天
        }

        echo "<td class='$class'>";
        if (date("n", $date) == $month) {             // 只顯示這個月的日子
            echo date("j", $date);
        }
        echo "</td>";
    }
    echo "</tr>";
}
?>
</table>
</div>
</body>
</html>
