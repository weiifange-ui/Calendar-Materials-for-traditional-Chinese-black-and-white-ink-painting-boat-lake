<?php
/* =========================================================================
   第 8 步：登入、登出（這一步是獨立的小練習，不放月曆，專心看登入）

   這一步學到：
   - session_start() 和 $_SESSION：讓網站「記得你是誰」
     （像寄物櫃：伺服器幫你保管資料，瀏覽器拿著號碼牌，下次來就知道開哪個櫃子）
   - password_hash()：把密碼加密後再存，資料庫裡看不到原本的密碼
   - password_verify()：檢查輸入的密碼對不對
   - SQL 的 INSERT（註冊）和 SELECT（登入）

   學完這一步，再去看 ../index.php：那裡把第 1～8 步全部合在一起，
   而且每個人只看得到自己的行程（多了 user_id）。
   ========================================================================= */

session_start();                                   // 一定要在最前面：打開寄物櫃

require "../includes/config.php";
$pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS);

$message = "";                                     // 要顯示給使用者看的訊息

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST["action"] ?? "";
    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($action == "logout") {
        // 登出：把寄物櫃清空
        $_SESSION = [];
        $message = "已登出";

    } elseif ($username == "" || strlen($password) < 6) {
        $message = "請輸入帳號，密碼至少 6 個字";

    } elseif ($action == "register") {
        // 註冊：先看帳號有沒有人用過
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $message = "這個帳號已經有人使用了";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);       // 密碼加密
            // echo $hash;   // 想看加密後長什麼樣子，把前面的 // 拿掉
            $stmt = $pdo->prepare("INSERT INTO users (username, password_hash) VALUES (?, ?)");
            $stmt->execute([$username, $hash]);
            $_SESSION["username"] = $username;                         // 註冊完直接登入：放進寄物櫃
            $message = "註冊成功";
        }

    } elseif ($action == "login") {
        // 登入：找出這個帳號加密後的密碼，檢查對不對
        $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);                         // 找不到會得到 false
        if ($row && password_verify($password, $row["password_hash"])) {
            $_SESSION["username"] = $username;                         // 放進寄物櫃
            $message = "登入成功";
        } else {
            $message = "帳號或密碼不正確";
        }
    }
}

// 寄物櫃裡有沒有 username？有就代表登入了
$who = $_SESSION["username"] ?? "";
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>第 8 步：登入</title>
<link rel="stylesheet" href="lesson.css">
</head>
<body>
<div class="box">
<p class="step">第 8 步：登入、登出</p>
<h2>登入</h2>

<?php if ($message != ""): ?>
    <p class="msg"><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<?php if ($who != ""): ?>
    <!-- 已經登入 -->
    <p>你好，<?= htmlspecialchars($who) ?>。重新整理這一頁，你還是登入的狀態，因為資料存在寄物櫃（Session）裡。</p>
    <form method="post">
        <input type="hidden" name="action" value="logout">
        <button>登出</button>
    </form>
<?php else: ?>
    <!-- 還沒登入：兩個按鈕都在同一個表單，用 name="action" 的 value 分辨按了哪一個 -->
    <form method="post">
        <p><input name="username" placeholder="帳號"></p>
        <p><input type="password" name="password" placeholder="密碼（至少 6 個字）"></p>
        <button name="action" value="login">登入</button>
        <button name="action" value="register">註冊</button>
    </form>
<?php endif; ?>
</div>
</body>
</html>
