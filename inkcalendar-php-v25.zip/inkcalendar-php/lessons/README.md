# 學習路線：一步一步做出 PHP 萬年曆

這個資料夾從「和老師一樣的月曆」開始，每一步只多學一點點。
每個檔案都能單獨打開，新增的地方都標了 **★ 新增**，和上一步對照著看就知道多了什麼。

| 步驟 | 檔案 | 新增的功能 | 學到的 PHP |
| --- | --- | --- | --- |
| 1 | `step1_calendar.php` | 月曆、上一個月、下一個月 | `$_GET`、`date()`、`strtotime()`、`for` 迴圈 |
| 2 | `step2_today.php` | 今年第幾天、回到今天、點選日期 | `date("z")`、`explode()`、`checkdate()` |
| 3 | `step3_holidays.php` | 國定假日、補假、節日 | 有名稱的陣列、`isset()` |
| 4 | `step4_lunar.php` | 點選日期顯示農曆 | `require`、呼叫函式 |
| 5 | `step5_events.php` | 從資料庫讀出行程 | `PDO`、SQL `SELECT`、`htmlspecialchars()` |
| 6 | `step6_add.php` | 新增行程 | 表單、`$_POST`、SQL `INSERT`、`header()` |
| 7 | `step7_delete.php` | 刪除行程 | 隱藏欄位、SQL `DELETE` |
| 8 | `step8_login.php` | 註冊、登入、登出 | `$_SESSION`、`password_hash()` |

學完第 8 步，再打開外面的 `../index.php`：它就是把 1～8 步合在一起的完整版，
變數名稱和寫法都和這裡一樣，只是多了水墨畫面、每個人只看得到自己的行程、修改行程這些功能。

## 開始之前

1. 用 phpMyAdmin 匯入 `../schema.sql`（第 5 步之後會用到資料庫）。
2. 把 `../includes/config.sample.php` 複製成 `../includes/config.php`。
3. 打開 `http://localhost/inkcalendar-php/lessons/step1_calendar.php`。

## 和老師的 calendar.php 有什麼不同

第 1 步幾乎和老師的一樣，只改了兩行（檔案裡標了 ★）：

1. `(int)($_GET['month'] ?? date('n'))`：網址上的值先轉成數字，避免有人在網址裡放奇怪的文字。
2. `$firstDay = "$year-$month-1";`：老師寫的 `date("Y-$month-1")` 裡的 `Y` 永遠是「今年」，
   翻到明年時，標題會變成明年，但表格還是畫今年的那個月。改成用 `$year` 就會跟著年份走。

## 學習小技巧

- 每一步都有幾行被 `//` 註解掉的 `echo` 或 `print_r`，把 `//` 拿掉，就能看到那個變數裡面的內容。
- 看不懂某一行時，先猜它會印出什麼，再拿掉 `//` 印出來驗證。
- 想看兩步之間差在哪，搜尋「★ 新增」。
