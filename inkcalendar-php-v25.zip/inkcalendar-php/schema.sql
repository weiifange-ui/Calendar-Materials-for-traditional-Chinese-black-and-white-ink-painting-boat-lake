-- =========================================================================
-- 水墨萬年曆 PHP 學習版｜建立資料庫（schema.sql）
--
-- 用法：XAMPP 啟動 MySQL → 打開 http://localhost/phpmyadmin
--       → 上方「匯入」→ 選這個檔案 → 按「執行」。只要做一次。
-- SQL 裡，兩個減號開頭的是註解。
-- =========================================================================

-- 用 UTF-8 傳送中文，範例資料才不會變成亂碼
SET NAMES utf8mb4;

-- 建立資料庫（已經有就不會重複建立）；utf8mb4 讓中文能正確存放
CREATE DATABASE IF NOT EXISTS inkcalendar_php DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inkcalendar_php;

-- ===== 帳號 =====
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,                 -- 編號：自動 +1
  username      VARCHAR(30)  NOT NULL UNIQUE,                   -- 帳號：不能重複
  password_hash VARCHAR(255) NOT NULL,                          -- 加密後的密碼
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP  -- 註冊時間
);

-- ===== 行程（每一列是一個行程）=====
CREATE TABLE IF NOT EXISTS events (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT          NOT NULL,                  -- 這是誰的行程（對應 users 的 id）
  title      VARCHAR(60)  NOT NULL,                  -- 主旨
  event_date DATE         NOT NULL,                  -- 日期，例如 2026-11-10
  event_time TIME         NULL,                      -- 時間（可以不填，NULL 代表沒有值）
  category   VARCHAR(20)  NOT NULL DEFAULT 'life',   -- 分類
  important  TINYINT(1)   NOT NULL DEFAULT 0,        -- 重要：1 是，0 不是
  note       TEXT         NULL,                      -- 詳細內容
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (user_id, event_date),                       -- 索引：讓「找某人某天的行程」變快
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ===== 學習路線（lessons 資料夾）第 5～7 步用的練習表格 =====
-- 和上面的 events 很像，但沒有 user_id，不用登入就能練習
CREATE TABLE IF NOT EXISTS lesson_events (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  title      VARCHAR(60)  NOT NULL,       -- 主旨
  event_date DATE         NOT NULL,       -- 日期
  note       VARCHAR(200) NOT NULL DEFAULT ''   -- 備註
);
-- 兩筆範例行程，第 5 步打開就看得到（如果已經有資料就不會重複新增）
INSERT INTO lesson_events (title, event_date, note)
SELECT '交 PHP 作業', CURDATE(), '記得附上 README' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM lesson_events);
INSERT INTO lesson_events (title, event_date, note)
SELECT '和朋友吃飯', DATE_ADD(CURDATE(), INTERVAL 3 DAY), '晚上七點' FROM DUAL
WHERE (SELECT COUNT(*) FROM lesson_events) = 1;
