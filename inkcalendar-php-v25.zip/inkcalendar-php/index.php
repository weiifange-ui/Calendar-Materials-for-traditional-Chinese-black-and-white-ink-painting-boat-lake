<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜首頁（index.php）

   【先看 lessons 資料夾】
   這一頁是把 lessons/ 裡第 1～8 步合在一起的完整版。
   變數名稱、寫法都和 lessons（以及老師的 calendar.php）一樣，
   每一段都標了「（第 N 步）」，看不懂的時候可以回去看那一步。

   【這個檔案的結構】
   上半部（?> 之前）：純 PHP，負責準備資料
   下半部（?> 之後）：HTML，中間穿插 <?= ?> 把資料放進去
   ========================================================================= */


// ===== 0. 載入共用程式 =====
// require ：把另一個 PHP 檔載入進來，就能使用裡面的函式和變數（第 4 步）
require "includes/db.php";          // 資料庫、Session、h()、redirect()……（第 5～8 步的東西整理在這裡）
require "includes/lunar.php";       // 農曆換算（第 4 步）
require "includes/holidays.php";    // 國定假日與節日（第 3 步）

$user = currentUser();              // 目前登入的人（沒登入是 null）（第 8 步）
$week_str = ["日", "一", "二", "三", "四", "五", "六"];


// ===== 1. 從網址拿年、月；網址沒有就用這個月（第 1 步） =====
$month = (int)($_GET['month'] ?? date('n'));
$year  = (int)($_GET['year'] ?? date('Y'));
if ($month < 1 || $month > 12) {    // 網址上的月份不對（例如 13），就用這個月
    $month = (int)date('n');
}
if ($year < 1 || $year > 9999) {    // 網址上的年份不對（例如 abc 會變成 0），就用今年
    $year = (int)date('Y');
}


// ===== 2. 上一個月、下一個月（第 1 步） =====
if ($month == 1) {
    $prev_month = 12;
    $prev_year = $year - 1;
} else {
    $prev_month = $month - 1;
    $prev_year = $year;
}
if ($month == 12) {
    $next_month = 1;
    $next_year = $year + 1;
} else {
    $next_month = $month + 1;
    $next_year = $year;
}


// ===== 3. 算出月曆需要的數字（第 1 步） =====
$firstDay = "$year-$month-1";                                  // 這個月 1 號
$firstDayWeek = date("w", strtotime($firstDay));               // 1 號是星期幾（0 是星期日）
$theMonthDays = date("t", strtotime($firstDay));               // 這個月有幾天
$theMonthFirstDate = strtotime("-$firstDayWeek day", strtotime($firstDay));   // 月曆第一格的日期
$theMonthTotalDays = $theMonthDays + $firstDayWeek;
$theCalendarWeeks = ceil($theMonthTotalDays / 7);              // 需要幾列
// echo $firstDayWeek;      // 想看數字的時候，把前面的 // 拿掉


// ===== 4. 今年第幾天、還剩幾天（第 2 步） =====
$dayOfYear = date("z") + 1;
$daysInYear = date("L") == 1 ? 366 : 365;
$daysLeft = $daysInYear - $dayOfYear;


// ===== 5. 點選的是哪一天（第 2 步） =====
$today = date("Y-m-d");
$picked = $_GET['date'] ?? $today;
$parts = explode("-", $picked);
if (count($parts) != 3 || !checkdate((int)$parts[1], (int)$parts[2], (int)$parts[0])) {
    $picked = $today;                                          // 格式不對、或日期不存在，就用今天
    $parts = explode("-", $picked);
}
$pickedY = (int)$parts[0];
$pickedM = (int)$parts[1];
$pickedD = (int)$parts[2];


// ===== 6. 從資料庫讀出行程（第 5 步） =====
// 和第 5 步一樣，只是多了「user_id = 自己」：每個人只看得到自己的行程（第 8 步）
// 結果整理成：["2026-11-12" => [行程1, 行程2]]
$events = [];
if ($user) {
    $from = date("Y-m-d", $theMonthFirstDate);                                       // 月曆第一格
    $to   = date("Y-m-d", strtotime("+" . ($theCalendarWeeks * 7 - 1) . " day", $theMonthFirstDate));   // 月曆最後一格
    $from = min($from, $picked);                                                     // 點選的日子也要包含進來
    $to   = max($to, $picked);

    // ORDER BY：重要的排前面（DESC 是由大到小），再依時間排
    $stmt = $pdo->prepare(
        "SELECT * FROM events
         WHERE user_id = ? AND event_date BETWEEN ? AND ?
         ORDER BY important DESC, event_time IS NULL, event_time"
    );
    $stmt->execute([$user["id"], $from, $to]);
    foreach ($stmt->fetchAll() as $row) {
        $events[$row["event_date"]][] = $row;
    }
    // print_r($events);   // 想看整理後的樣子，把前面的 // 拿掉
}


// ===== 7. 網址有 ?edit=編號，代表要修改某個行程（第 6 步的進階版） =====
$editing = null;
if ($user && isset($_GET["edit"])) {
    // 只能找「自己的」行程（user_id = 自己）
    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = ? AND user_id = ?");
    $stmt->execute([(int)$_GET["edit"], $user["id"]]);
    $editing = $stmt->fetch();
    if (!$editing) {
        $editing = null;
    }
}


// ===== 8. 點選那一天的資料（第 3、4 步） =====
$pickedInfo = dayFestivals($pickedY, $pickedM, $pickedD);                         // 節日、假日
$pickedLunar = ($pickedY >= 1900 && $pickedY <= 2100) ? lunarText(toLunar($pickedY, $pickedM, $pickedD)) : "";   // 農曆
$pickedTerm = solarTerm($pickedY, $pickedM, $pickedD);                            // 節氣
$pickedWeek = $week_str[date("w", strtotime($picked))];
$pickedEvents = $events[$picked] ?? [];

// 這個月、這一天的網址（修改、取消修改會用到）
$thisPage = "index.php?month=$month&year=$year&date=$picked";

$message = flash();   // 上一頁留下的提示訊息（例如「已新增行程」）

// 下一行的「問號、大於」記號代表：PHP 到這裡暫停，接下來開始是 HTML
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>水墨萬年曆（PHP 學習版）</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="decor.css">   <!-- 背景山水、花框、右上角小功能的樣式 -->
</head>
<!-- data-month：把「現在看的是幾月」交給 JavaScript，花框才知道要畫哪一個月的花 -->
<body data-month="<?= $month ?>">

<?php
// include ：把另一個檔案的內容「貼」進來。背景山水和登入頁共用，所以獨立成一個檔案
include "includes/scene.php";
?>

<!-- 左上角：登入狀態 -->
<header class="top">
  <?php if ($user): ?>
    <?php /* 下面的「< ?= 值 ? >」寫法（實際上中間沒有空白），是「< ?php echo 值; ? >」的簡寫：把 PHP 的值印進 HTML */ ?>
    <span>你好，<?= h($user["name"]) ?></span>
    <!-- 登出用表單送出（POST），並附上防偽造的暗號 csrf -->
    <form method="post" action="logout.php" class="inline">
      <input type="hidden" name="csrf" value="<?= h(csrfToken()) ?>">
      <button>登出</button>
    </form>
  <?php else: ?>
    <a href="login.php">登入／註冊</a>
  <?php endif; ?>
  <!-- if (...): ... else: ... endif; 是 PHP 在 HTML 裡常用的寫法，和 if { } else { } 意思一樣 -->
</header>

<main class="calendar">
  <!-- 上下兩條水墨花框（由 js/decor.js 畫進去） -->
  <div class="garland top" id="gTop" aria-hidden="true"></div>
  <div class="garland bottom" id="gBottom" aria-hidden="true"></div>

  <h1><?= $year ?> 年 <?= $month ?> 月</h1>

  <!-- 切換月份：全部都是「連結」，點了就會帶著新的網址重新載入整頁 -->
  <nav class="nav">
    <a href="index.php?month=<?= $month ?>&year=<?= $year - 1 ?>">« 上一年</a>
    <a href="index.php?month=<?= $prev_month ?>&year=<?= $prev_year ?>">‹ 上個月</a>
    <a href="index.php">今天</a>
    <a href="index.php?month=<?= $next_month ?>&year=<?= $next_year ?>">下個月 ›</a>
    <a href="index.php?month=<?= $month ?>&year=<?= $year + 1 ?>">下一年 »</a>
  </nav>
  <p class="info">今天是 <?= date("Y") ?> 年第 <?= $dayOfYear ?> 天，今年還剩 <?= $daysLeft ?> 天</p>

  <?php if ($message): ?>
    <p class="flash"><?= h($message) ?></p>
  <?php endif; ?>

  <table>
    <thead>
      <tr>
        <!-- foreach：把 $week_str 裡的「日、一、二……」一個一個印成 <th> -->
        <?php foreach ($week_str as $w): ?><th><?= $w ?></th><?php endforeach; ?>
      </tr>
    </thead>
    <tbody>
    <?php
    // ===== 用迴圈畫出月曆（第 1 步的寫法，再加上第 2、3、5 步的東西） =====
    for ($i = 0; $i < $theCalendarWeeks; $i++) {          // 一列一列畫
        echo "<tr>";
        for ($j = 0; $j < 7; $j++) {                      // 每一列 7 格
            $days = $i * 7 + $j;
            $date = strtotime("+$days day", $theMonthFirstDate);   // 這一格是哪一天
            $key = date("Y-m-d", $date);                  // 例如 "2026-11-12"
            $info = dayFestivals((int)date("Y", $date), (int)date("n", $date), (int)date("j", $date));   // 節日（第 3 步）
            $dayEvents = $events[$key] ?? [];            // 這天的行程（第 5 步）

            // 決定這一格的 class（CSS 會依照 class 改變外觀）
            $class = "";
            if (date("n", $date) != $month) {
                $class = $class . " other ";              // 上個月、下個月的日子（顯示得淡一點）
            }
            if (date("w", $date) == 0 || date("w", $date) == 6) {
                $class = $class . " weekend ";            // 週末
            }
            if ($info["off"]) {
                $class = $class . " off ";                // 國定假日（第 3 步）
            }
            if ($key == $today) {
                $class = $class . " today ";              // 今天
            }
            if ($key == $picked) {
                $class = $class . " picked ";             // 點選的那一天（第 2 步）
            }

            $link = "index.php?month=$month&year=$year&date=$key";   // 點了就選這一天（第 2 步）
            echo "<td><a class='$class' href='$link'>";
            echo "<span class='num'>" . date("j", $date) . "</span>";
            if ($info["off"]) {
                echo "<span class='tag'>休</span>";       // 放假（第 3 步）
            }
            echo "<span class='label'>" . h($info["names"][0] ?? "") . "</span>";   // 第一個節日名稱
            if (count($dayEvents) > 0) {                  // 第一個行程的主旨；還有更多就顯示 +幾（第 5 步）
                echo "<span class='ev'>" . ($dayEvents[0]["important"] ? "★" : "") . h($dayEvents[0]["title"]);
                if (count($dayEvents) > 1) {
                    echo "<em>+" . (count($dayEvents) - 1) . "</em>";
                }
                echo "</span>";
            }
            echo "</a></td>";
        }
        echo "</tr>";
    }
    ?>
    </tbody>
  </table>

  <!-- ===== 點選那一天的詳細資料 ===== -->
  <section class="detail">
    <div class="d-date"><?= $pickedY ?> 年 <?= $pickedM ?> 月 <?= $pickedD ?> 日　星期<?= $pickedWeek ?></div>
    <div class="d-lunar"><?= $pickedLunar ? "農曆 " . $pickedLunar : "農曆只能換算 1900～2100 年" ?><?= $pickedTerm ? "　" . $pickedTerm : "" ?></div>

    <div class="d-fest">
      <?php foreach ($pickedInfo["names"] as $name): ?>
        <span class="chip"><?= h($name) ?></span>
      <?php endforeach; ?>
      <?php if ($pickedInfo["off"] && !$pickedInfo["official"]): ?>
        <span class="note">此年份沒有官方資料，依固定日期推算，不含補假</span>
      <?php endif; ?>
    </div>

    <h2>行程與紀念日</h2>
    <?php if (!$user): ?>
      <p class="muted"><a href="login.php">登入</a>後就可以新增行程。</p>
    <?php else: ?>
      <ul class="ev-list">
        <?php if (!$pickedEvents): ?>
          <li class="muted">這天還沒有安排</li>
        <?php endif; ?>
        <?php foreach ($pickedEvents as $ev): ?>
          <li>
            <div class="ev-main">
              <strong><?= $ev["important"] ? "★ " : "" ?><?= h($ev["title"]) ?></strong>
              <span class="muted">
                <!-- substr(時間, 0, 5)：資料庫的時間是 14:00:00，只取前 5 個字變成 14:00 -->
                <?= $ev["event_time"] ? h(substr($ev["event_time"], 0, 5)) . "　" : "" ?><?= h(CATEGORIES[$ev["category"]] ?? "其他") ?>
              </span>
              <?php if ($ev["note"]): ?>
                <!-- nl2br：把換行變成 <br>，詳細內容的換行才會顯示出來 -->
                <p class="note-text"><?= nl2br(h($ev["note"])) ?></p>
              <?php endif; ?>
            </div>
            <div class="ev-actions">
              <!-- 修改：連到同一頁，網址多帶 edit=編號，下面的表單就會變成修改模式 -->
              <a href="<?= $thisPage ?>&edit=<?= (int)$ev["id"] ?>#form">修改</a>
              <!-- 刪除：用表單送出（POST），onsubmit 會先跳出確認視窗 -->
              <form method="post" action="event_delete.php" class="inline" onsubmit="return confirm('確定要刪除嗎？');">
                <input type="hidden" name="csrf" value="<?= h(csrfToken()) ?>">
                <input type="hidden" name="id" value="<?= (int)$ev["id"] ?>">
                <button class="danger">刪除</button>
              </form>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>

      <!-- ===== 新增／修改行程的表單 =====
           method="post"：用 POST 送出（資料裝在信封裡）
           action="event_save.php"：送給 event_save.php 處理 -->
      <form method="post" action="event_save.php" class="ev-form" id="form">
        <h3><?= $editing ? "修改行程" : "新增行程" ?></h3>
        <input type="hidden" name="csrf" value="<?= h(csrfToken()) ?>">
        <?php if ($editing): ?>
          <!-- 修改時，偷偷帶著行程編號，event_save.php 才知道要改哪一個 -->
          <input type="hidden" name="id" value="<?= (int)$editing["id"] ?>">
        <?php endif; ?>

        <!-- name="title"：送出後，PHP 用 $_POST["title"] 拿到這個欄位的值
             required：沒填就不能送出 -->
        <label>主旨<input name="title" maxlength="60" required value="<?= h($editing["title"] ?? "") ?>" placeholder="和朋友吃飯"></label>
        <div class="row">
          <label>日期<input type="date" name="date" required value="<?= h($editing["event_date"] ?? $picked) ?>"></label>
          <label>時間<input type="time" name="time" value="<?= h(isset($editing["event_time"]) ? substr($editing["event_time"], 0, 5) : "") ?>"></label>
        </div>
        <div class="row">
          <label>分類
            <select name="category">
              <?php foreach (CATEGORIES as $value => $text): ?>
                <!-- selected：預設選中這一項 -->
                <option value="<?= $value ?>" <?= ($editing["category"] ?? "life") === $value ? "selected" : "" ?>><?= $text ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label class="check"><input type="checkbox" name="important" value="1" <?= !empty($editing["important"]) ? "checked" : "" ?>> 重要</label>
        </div>
        <label>詳細內容<textarea name="note" rows="3" placeholder="地點、要帶的東西、備註"><?= h($editing["note"] ?? "") ?></textarea></label>
        <div class="actions">
          <?php if ($editing): ?>
            <a href="<?= $thisPage ?>">取消修改</a>
          <?php endif; ?>
          <button class="primary"><?= $editing ? "儲存修改" : "新增" ?></button>
        </div>
      </form>
    <?php endif; ?>
  </section>
</main>

<footer class="foot">PHP 學習版：月曆、農曆、假日、帳號、行程由 PHP 處理；背景動畫、占卜、每日學習、城市天氣是 JavaScript。</footer>

<?php
// 右上角三個小功能（占卜、每日學習、城市天氣），和 GitHub 完整版一樣
include "includes/widgets.php";
?>

<!-- 左下角：改變花框 -->
<div class="tools">
  <button id="redraw" title="讓這個月的花框換一種樣子">改變花框</button>
  <!-- 開關二胡飄出來的音符（程式在 js/cursor.js） -->
  <button id="trailBtn" aria-pressed="false" title="開關二胡飄出來的音符">關閉音符</button>
</div>

<!-- JavaScript：順序很重要，後面的檔案會用到前面的東西 -->
<script src="js/config.js"></script>      <!-- 設定（氣象署授權碼，選填） -->
<script src="js/flowers.js"></script>     <!-- 畫水墨花朵 -->
<script src="js/decor.js"></script>       <!-- 共用工具、花框 -->
<script src="js/study.js"></script>       <!-- 每日學習 -->
<script src="js/townships.js"></script>   <!-- 台灣 368 個鄉鎮市區的座標 -->
<script src="js/weather.js"></script>     <!-- 城市天氣 -->
<script src="js/divination.js"></script>  <!-- 八卦占卜 -->
<script src="js/cursor.js"></script>      <!-- 二胡游標與音符 -->
</body>
</html>
