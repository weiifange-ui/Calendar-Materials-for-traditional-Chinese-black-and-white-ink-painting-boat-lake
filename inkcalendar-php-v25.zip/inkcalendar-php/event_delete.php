<?php
/* =========================================================================
   水墨萬年曆 PHP 學習版｜刪除行程（event_delete.php）

   index.php 的「刪除」按鈕會把行程編號送到這裡。
   這一頁沒有畫面：檢查 → 從資料庫刪除 → 跳回 index.php
   ========================================================================= */

require "includes/db.php";

$user = currentUser();
if (!$user) {
    redirect("login.php");
}
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirect("index.php");
}
checkCsrf();

$id = (int)($_POST["id"] ?? 0);

// 先查出這個行程的日期（刪除後要跳回那一天）
// AND user_id = ? ：只能刪自己的行程
$stmt = $pdo->prepare("SELECT event_date FROM events WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user["id"]]);
$event = $stmt->fetch();

if (!$event) {
    flash("找不到這個行程");
    redirect("index.php");
}

// DELETE FROM 表格 WHERE 條件 ：刪除符合條件的資料
$stmt = $pdo->prepare("DELETE FROM events WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user["id"]]);
flash("已刪除行程");

// explode("-", "2026-11-10") ：用「-」把文字切開 → ["2026", "11", "10"]
$parts = explode("-", $event["event_date"]);
redirect("index.php?month=" . (int)$parts[1] . "&year=" . (int)$parts[0] . "&date=" . $event["event_date"]);
